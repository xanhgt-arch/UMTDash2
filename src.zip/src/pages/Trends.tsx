import React, { useState } from 'react';
import { Grid, Paper, Typography, Box, ToggleButton, ToggleButtonGroup } from '@mui/material';
import { LineChart, Line, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const generateTrendData = () => {
  const data = [];
  for (let i = 0; i < 12; i++) {
    data.push({
      month: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][i],
      usage: Math.floor(Math.random() * 50) + 50,
      engagement: Math.floor(Math.random() * 40) + 40,
      retention: Math.floor(Math.random() * 30) + 60,
    });
  }
  return data;
};

const Trends: React.FC = () => {
  const [timeframe, setTimeframe] = useState('monthly');
  const trendData = generateTrendData();

  return (
    <Box sx={{ flexGrow: 1, pb: 4 }}>
      <Typography
        variant="h4"
        gutterBottom
        sx={{
          fontWeight: 700,
          background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
          WebkitBackgroundClip: 'text',
          WebkitTextFillColor: 'transparent',
          mb: 3,
        }}
      >
        📈 Trends & Analysis
      </Typography>

      <Grid container spacing={3}>
        <Grid item xs={12}>
          <Paper
            sx={{
              p: 3,
              background: 'rgba(255, 255, 255, 0.95)',
              backdropFilter: 'blur(10px)',
              borderRadius: 2,
              boxShadow: '0 8px 32px 0 rgba(31, 38, 135, 0.1)',
              border: '1px solid rgba(255, 255, 255, 0.2)',
            }}
          >
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
              <Typography variant="h6" sx={{ fontWeight: 600, color: '#667eea' }}>
                📊 Usage Trends Over Time
              </Typography>
              <ToggleButtonGroup
                value={timeframe}
                exclusive
                onChange={(e, newTimeframe) => setTimeframe(newTimeframe || timeframe)}
                size="small"
                sx={{
                  '& .MuiToggleButton-root': {
                    borderColor: 'rgba(102, 126, 234, 0.3)',
                    color: '#667eea',
                    textTransform: 'none',
                    fontWeight: 600,
                    '&.Mui-selected': {
                      backgroundColor: 'rgba(102, 126, 234, 0.15)',
                      borderColor: '#667eea',
                    },
                  },
                }}
              >
                <ToggleButton value="weekly">Weekly</ToggleButton>
                <ToggleButton value="monthly">Monthly</ToggleButton>
                <ToggleButton value="yearly">Yearly</ToggleButton>
              </ToggleButtonGroup>
            </Box>
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={trendData}>
                <defs>
                  <linearGradient id="colorUsage" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#667eea" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#667eea" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="colorEngagement" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#764ba2" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#764ba2" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(102, 126, 234, 0.1)" />
                <XAxis dataKey="month" stroke="#999" />
                <YAxis stroke="#999" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'rgba(255, 255, 255, 0.95)',
                    border: '1px solid rgba(102, 126, 234, 0.2)',
                    borderRadius: 8,
                    boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)',
                  }}
                />
                <Legend />
                <Area
                  type="monotone"
                  dataKey="usage"
                  stroke="#667eea"
                  fillOpacity={1}
                  fill="url(#colorUsage)"
                  name="Usage"
                />
                <Area
                  type="monotone"
                  dataKey="engagement"
                  stroke="#764ba2"
                  fillOpacity={1}
                  fill="url(#colorEngagement)"
                  name="Engagement"
                />
              </AreaChart>
            </ResponsiveContainer>
          </Paper>
        </Grid>

        <Grid item xs={12} md={6}>
          <Paper
            sx={{
              p: 3,
              background: 'rgba(255, 255, 255, 0.95)',
              backdropFilter: 'blur(10px)',
              borderRadius: 2,
              boxShadow: '0 8px 32px 0 rgba(31, 38, 135, 0.1)',
              border: '1px solid rgba(255, 255, 255, 0.2)',
            }}
          >
            <Typography variant="h6" sx={{ fontWeight: 600, color: '#667eea', mb: 2 }}>
              🎯 Top Performers
            </Typography>
            {[
              { name: 'App 1', growth: '+24%', color: '#4caf50' },
              { name: 'App 5', growth: '+18%', color: '#2196f3' },
              { name: 'App 12', growth: '+15%', color: '#ff9800' },
            ].map((app, idx) => (
              <Box
                key={idx}
                sx={{
                  mb: 2,
                  p: 2,
                  backgroundColor: 'rgba(102, 126, 234, 0.05)',
                  borderRadius: 1,
                  borderLeft: `3px solid ${app.color}`,
                }}
              >
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <Typography sx={{ fontWeight: 600, color: '#333' }}>
                    {app.name}
                  </Typography>
                  <Typography sx={{ fontWeight: 700, color: app.color }}>
                    {app.growth}
                  </Typography>
                </Box>
              </Box>
            ))}
          </Paper>
        </Grid>

        <Grid item xs={12} md={6}>
          <Paper
            sx={{
              p: 3,
              background: 'rgba(255, 255, 255, 0.95)',
              backdropFilter: 'blur(10px)',
              borderRadius: 2,
              boxShadow: '0 8px 32px 0 rgba(31, 38, 135, 0.1)',
              border: '1px solid rgba(255, 255, 255, 0.2)',
            }}
          >
            <Typography variant="h6" sx={{ fontWeight: 600, color: '#764ba2', mb: 2 }}>
              📉 Declining Apps
            </Typography>
            {[
              { name: 'App 33', decline: '-12%', color: '#f44336' },
              { name: 'App 28', decline: '-8%', color: '#ff5722' },
              { name: 'App 19', decline: '-5%', color: '#ff9800' },
            ].map((app, idx) => (
              <Box
                key={idx}
                sx={{
                  mb: 2,
                  p: 2,
                  backgroundColor: 'rgba(244, 67, 54, 0.05)',
                  borderRadius: 1,
                  borderLeft: `3px solid ${app.color}`,
                }}
              >
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <Typography sx={{ fontWeight: 600, color: '#333' }}>
                    {app.name}
                  </Typography>
                  <Typography sx={{ fontWeight: 700, color: app.color }}>
                    {app.decline}
                  </Typography>
                </Box>
              </Box>
            ))}
          </Paper>
        </Grid>
      </Grid>
    </Box>
  );
};

export default Trends;