import React from 'react';
import { Grid, Paper, Typography, Box, List, ListItem, ListItemIcon, ListItemText } from '@mui/material';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import WarningIcon from '@mui/icons-material/Warning';
import InfoIcon from '@mui/icons-material/Info';
import FileDownloadIcon from '@mui/icons-material/FileDownload';

const ReportItem: React.FC<{ title: string; description: string; icon: React.ReactNode; status: 'success' | 'warning' | 'info' }> = ({
  title,
  description,
  icon,
  status,
}) => (
  <ListItem
    sx={{
      mb: 2,
      p: 2.5,
      backgroundColor: status === 'success' ? 'rgba(76, 175, 80, 0.05)' : status === 'warning' ? 'rgba(255, 152, 0, 0.05)' : 'rgba(33, 150, 243, 0.05)',
      borderRadius: 1.5,
      border: `1px solid ${status === 'success' ? 'rgba(76, 175, 80, 0.2)' : status === 'warning' ? 'rgba(255, 152, 0, 0.2)' : 'rgba(33, 150, 243, 0.2)'}`,
      '&:hover': {
        backgroundColor: status === 'success' ? 'rgba(76, 175, 80, 0.1)' : status === 'warning' ? 'rgba(255, 152, 0, 0.1)' : 'rgba(33, 150, 243, 0.1)',
        transition: 'all 0.3s ease',
      },
    }}
  >
    <ListItemIcon
      sx={{
        color: status === 'success' ? '#4caf50' : status === 'warning' ? '#ff9800' : '#2196f3',
        minWidth: 50,
      }}
    >
      {icon}
    </ListItemIcon>
    <ListItemText
      primary={
        <Typography sx={{ fontWeight: 600, color: '#333' }}>
          {title}
        </Typography>
      }
      secondary={
        <Typography sx={{ color: '#999', fontSize: '0.9rem', mt: 0.5 }}>
          {description}
        </Typography>
      }
    />
  </ListItem>
);

const Reports: React.FC = () => {
  return (
    <Box sx={{ flexGrow: 1, pb: 4 }}>
      <Typography
        variant="h4"
        gutterBottom
        sx={{
          fontWeight: 700,
          background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
          WebkitBackgroundClip: 'text',
          WebkitTextFillColor: 'transparent',
          mb: 3,
        }}
      >
        📋 Reports
      </Typography>

      <Grid container spacing={3}>
        <Grid item xs={12}>
          <Paper
            sx={{
              p: 3,
              background: 'rgba(255, 255, 255, 0.95)',
              backdropFilter: 'blur(10px)',
              borderRadius: 2,
              boxShadow: '0 8px 32px 0 rgba(31, 38, 135, 0.1)',
              border: '1px solid rgba(255, 255, 255, 0.2)',
            }}
          >
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
              <Typography variant="h6" sx={{ fontWeight: 600, color: '#667eea' }}>
                📊 System Health Status
              </Typography>
              <Box
                component="button"
                sx={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: 1,
                  padding: '8px 16px',
                  backgroundColor: 'rgba(102, 126, 234, 0.1)',
                  border: '1px solid rgba(102, 126, 234, 0.3)',
                  borderRadius: 1,
                  cursor: 'pointer',
                  transition: 'all 0.3s ease',
                  color: '#667eea',
                  fontWeight: 600,
                  fontSize: '0.9rem',
                  '&:hover': {
                    backgroundColor: 'rgba(102, 126, 234, 0.2)',
                  },
                }}
              >
                <FileDownloadIcon sx={{ fontSize: 18 }} />
                Export Report
              </Box>
            </Box>

            <List disablePadding>
              <ReportItem
                icon={<CheckCircleIcon />}
                title="Application Performance"
                description="All applications running at optimal performance. 99.8% uptime recorded."
                status="success"
              />
              <ReportItem
                icon={<CheckCircleIcon />}
                title="Data Integrity"
                description="All data validation checks passed. Database consistency verified."
                status="success"
              />
              <ReportItem
                icon={<WarningIcon />}
                title="Storage Usage"
                description="Storage usage at 78% capacity. Consider cleanup soon."
                status="warning"
              />
              <ReportItem
                icon={<InfoIcon />}
                title="Scheduled Maintenance"
                description="Next maintenance window: Sunday 2:00 AM UTC"
                status="info"
              />
            </List>
          </Paper>
        </Grid>

        <Grid item xs={12} sm={6}>
          <Paper
            sx={{
              p: 3,
              background: 'rgba(255, 255, 255, 0.95)',
              backdropFilter: 'blur(10px)',
              borderRadius: 2,
              boxShadow: '0 8px 32px 0 rgba(31, 38, 135, 0.1)',
              border: '1px solid rgba(255, 255, 255, 0.2)',
            }}
          >
            <Typography variant="h6" sx={{ fontWeight: 600, color: '#667eea', mb: 2 }}>
              📅 Recent Reports
            </Typography>
            {['Daily Summary', 'Weekly Report', 'Monthly Overview'].map((report, idx) => (
              <Box
                key={idx}
                sx={{
                  p: 2,
                  mb: idx < 2 ? 2 : 0,
                  backgroundColor: 'rgba(102, 126, 234, 0.05)',
                  borderRadius: 1,
                  cursor: 'pointer',
                  transition: 'all 0.3s ease',
                  '&:hover': {
                    backgroundColor: 'rgba(102, 126, 234, 0.1)',
                    transform: 'translateX(5px)',
                  },
                }}
              >
                <Typography sx={{ fontWeight: 600, color: '#667eea', fontSize: '0.95rem' }}>
                  {report}
                </Typography>
                <Typography sx={{ color: '#999', fontSize: '0.85rem', mt: 0.5 }}>
                  Generated {Math.floor(Math.random() * 7) + 1} days ago
                </Typography>
              </Box>
            ))}
          </Paper>
        </Grid>

        <Grid item xs={12} sm={6}>
          <Paper
            sx={{
              p: 3,
              background: 'rgba(255, 255, 255, 0.95)',
              backdropFilter: 'blur(10px)',
              borderRadius: 2,
              boxShadow: '0 8px 32px 0 rgba(31, 38, 135, 0.1)',
              border: '1px solid rgba(255, 255, 255, 0.2)',
            }}
          >
            <Typography variant="h6" sx={{ fontWeight: 600, color: '#764ba2', mb: 2 }}>
              🎯 Performance Metrics
            </Typography>
            {[
              { label: 'API Response Time', value: '145ms', target: '200ms' },
              { label: 'Database Queries', value: '1,245', target: '2,000' },
              { label: 'User Sessions', value: '892', target: '5,000' },
            ].map((metric, idx) => (
              <Box key={idx} sx={{ mb: idx < 2 ? 2 : 0 }}>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 0.5 }}>
                  <Typography sx={{ fontSize: '0.9rem', fontWeight: 500, color: '#666' }}>
                    {metric.label}
                  </Typography>
                  <Typography sx={{ fontSize: '0.9rem', fontWeight: 600, color: '#667eea' }}>
                    {metric.value}
                  </Typography>
                </Box>
                <Box
                  sx={{
                    height: 6,
                    backgroundColor: 'rgba(102, 126, 234, 0.1)',
                    borderRadius: 3,
                    overflow: 'hidden',
                  }}
                >
                  <Box
                    sx={{
                      height: '100%',
                      width: `${(parseInt(metric.value.replace(/,/g, '')) / parseInt(metric.target.replace(/,/g, ''))) * 100}%`,
                      backgroundColor: 'linear-gradient(90deg, #667eea 0%, #764ba2 100%)',
                      transition: 'width 0.3s ease',
                    }}
                  />
                </Box>
              </Box>
            ))}
          </Paper>
        </Grid>
      </Grid>
    </Box>
  );
};

export default Reports;