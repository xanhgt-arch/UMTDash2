import React from 'react';
import { Grid, Paper, Typography, Box, Card, CardContent } from '@mui/material';
import TrendingUpIcon from '@mui/icons-material/TrendingUp';
import PeopleIcon from '@mui/icons-material/People';
import StorageIcon from '@mui/icons-material/Storage';
import SpeedIcon from '@mui/icons-material/Speed';

const StatCard: React.FC<{ icon: React.ReactNode; label: string; value: string; trend?: string }> = ({
  icon,
  label,
  value,
  trend,
}) => (
  <Card
    sx={{
      background: 'linear-gradient(135deg, rgba(102, 126, 234, 0.1) 0%, rgba(118, 75, 162, 0.1) 100%)',
      backdropFilter: 'blur(10px)',
      border: '1px solid rgba(102, 126, 234, 0.2)',
      borderRadius: 2,
      transition: 'all 0.3s ease',
      '&:hover': {
        transform: 'translateY(-5px)',
        boxShadow: '0 12px 40px rgba(102, 126, 234, 0.2)',
      },
    }}
  >
    <CardContent>
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 1 }}>
        <Box
          sx={{
            backgroundColor: 'rgba(102, 126, 234, 0.2)',
            borderRadius: 1.5,
            p: 1.5,
            display: 'flex',
            color: '#667eea',
          }}
        >
          {icon}
        </Box>
        {trend && (
          <Typography sx={{ color: '#4caf50', fontWeight: 700, fontSize: '0.9rem' }}>
            {trend}
          </Typography>
        )}
      </Box>
      <Typography sx={{ color: '#999', fontSize: '0.85rem', fontWeight: 600, mb: 0.5 }}>
        {label}
      </Typography>
      <Typography sx={{ fontWeight: 700, fontSize: '2rem', color: '#667eea' }}>
        {value}
      </Typography>
    </CardContent>
  </Card>
);

const Analytics: React.FC = () => {
  return (
    <Box sx={{ flexGrow: 1, pb: 4 }}>
      <Typography
        variant="h4"
        gutterBottom
        sx={{
          fontWeight: 700,
          background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
          WebkitBackgroundClip: 'text',
          WebkitTextFillColor: 'transparent',
          mb: 3,
        }}
      >
        📊 Analytics Overview
      </Typography>

      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard icon={<TrendingUpIcon sx={{ fontSize: 28 }} />} label="Total Usage" value="24.5K" trend="+12%" />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard icon={<PeopleIcon sx={{ fontSize: 28 }} />} label="Active Apps" value="35" trend="+5%" />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard icon={<StorageIcon sx={{ fontSize: 28 }} />} label="Data Points" value="2.1M" trend="+8%" />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard icon={<SpeedIcon sx={{ fontSize: 28 }} />} label="Avg Speed" value="98ms" trend="-2%" />
        </Grid>
      </Grid>

      <Grid container spacing={3}>
        <Grid item xs={12}>
          <Paper
            sx={{
              p: 3,
              background: 'rgba(255, 255, 255, 0.95)',
              backdropFilter: 'blur(10px)',
              borderRadius: 2,
              boxShadow: '0 8px 32px 0 rgba(31, 38, 135, 0.1)',
              border: '1px solid rgba(255, 255, 255, 0.2)',
            }}
          >
            <Typography variant="h6" sx={{ fontWeight: 600, color: '#667eea', mb: 2 }}>
              📈 Key Insights
            </Typography>
            <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', md: '1fr 1fr' }, gap: 2 }}>
              {[
                { title: 'Peak Usage Hour', value: '2:00 PM - 3:00 PM' },
                { title: 'Most Used Category', value: 'Productivity (45%)' },
                { title: 'Average Session', value: '24 minutes' },
                { title: 'User Retention', value: '92.5%' },
              ].map((insight, idx) => (
                <Box key={idx} sx={{ p: 2, backgroundColor: 'rgba(102, 126, 234, 0.05)', borderRadius: 1.5 }}>
                  <Typography sx={{ color: '#999', fontSize: '0.85rem', fontWeight: 600, mb: 0.5 }}>
                    {insight.title}
                  </Typography>
                  <Typography sx={{ fontWeight: 700, color: '#667eea', fontSize: '1.2rem' }}>
                    {insight.value}
                  </Typography>
                </Box>
              ))}
            </Box>
          </Paper>
        </Grid>
      </Grid>
    </Box>
  );
};

export default Analytics;