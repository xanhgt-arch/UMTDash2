import React, { useState, useEffect } from 'react';
import { Grid, Paper, Typography, Box, TextField, FormControl, InputLabel, Select, MenuItem, Button, Checkbox, FormControlLabel, FormGroup } from '@mui/material';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import { Bar, Line } from 'react-chartjs-2';
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, LineElement, PointElement, Title, Tooltip, Legend } from 'chart.js';
import * as XLSX from 'xlsx';

ChartJS.register(CategoryScale, LinearScale, BarElement, LineElement, PointElement, Title, Tooltip, Legend);

// Mock data for demonstration
const generateMockData = (apps: number, days: number) => {
  const data = [];
  const appNames = Array.from({ length: apps }, (_, i) => `App ${i + 1}`);
  const startDate = new Date('2023-01-01');

  for (let i = 0; i < apps; i++) {
    for (let j = 0; j < days; j++) {
      data.push({
        app: appNames[i],
        type: ['Productivity', 'Communication', 'Development'][i % 3],
        date: new Date(startDate.getTime() + j * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        usage: Math.floor(Math.random() * 100) + 10
      });
    }
  }
  return data;
};

const mockData = generateMockData(35, 30);

const UsageDashboard: React.FC = () => {
  const [startDate, setStartDate] = useState<Date | null>(new Date('2023-01-01'));
  const [endDate, setEndDate] = useState<Date | null>(new Date('2023-01-30'));
  const [selectedTypes, setSelectedTypes] = useState<string[]>(['Productivity', 'Communication', 'Development']);
  const [filteredData, setFilteredData] = useState(mockData);

  const [compareApp1, setCompareApp1] = useState('App 1');
  const [compareApp2, setCompareApp2] = useState('App 2');

  useEffect(() => {
    const filtered = mockData.filter(item => {
      const itemDate = new Date(item.date);
      const inDateRange = (!startDate || itemDate >= startDate) && (!endDate || itemDate <= endDate);
      const inType = selectedTypes.includes(item.type);
      return inDateRange && inType;
    });
    setFilteredData(filtered);
  }, [startDate, endDate, selectedTypes]);

  const handleTypeChange = (type: string) => {
    setSelectedTypes(prev =>
      prev.includes(type) ? prev.filter(t => t !== type) : [...prev, type]
    );
  };

  const exportToExcel = () => {
    const ws = XLSX.utils.json_to_sheet(filteredData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Usage Data');
    XLSX.writeFile(wb, `Application_Usage_${startDate?.toISOString().split('T')[0]}_${endDate?.toISOString().split('T')[0]}.xlsx`);
  };

  // Prepare data for Graph 1 (Bar chart)
  const appTotals = filteredData.reduce((acc, item) => {
    acc[item.app] = (acc[item.app] || 0) + item.usage;
    return acc;
  }, {} as Record<string, number>);

  const barData = {
    labels: Object.keys(appTotals),
    datasets: [{
      label: 'Total Usage',
      data: Object.values(appTotals),
      backgroundColor: 'rgba(75, 192, 192, 0.6)',
    }]
  };

  const barOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'top' as const,
      },
      title: {
        display: false,
      },
    },
  };

  // Prepare data for Graph 2 (Line chart)
  const dateTotals = filteredData.reduce((acc, item) => {
    acc[item.date] = (acc[item.date] || 0) + item.usage;
    return acc;
  }, {} as Record<string, number>);

  const lineData = {
    labels: Object.keys(dateTotals).sort(),
    datasets: [{
      label: 'Daily Usage',
      data: Object.keys(dateTotals).sort().map(date => dateTotals[date]),
      borderColor: 'rgba(255, 99, 132, 1)',
      backgroundColor: 'rgba(255, 99, 132, 0.2)',
    }]
  };

  const lineOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'top' as const,
      },
      title: {
        display: false,
      },
    },
  };

  // Prepare data for Graph 3 (Comparison)
  const compareData = filteredData.filter(item =>
    item.app === compareApp1 || item.app === compareApp2
  );

  const compareTotals = compareData.reduce((acc, item) => {
    if (!acc[item.app]) acc[item.app] = {};
    acc[item.app][item.date] = (acc[item.app][item.date] || 0) + item.usage;
    return acc;
  }, {} as Record<string, Record<string, number>>);

  const compareChartData = {
    labels: Object.keys(compareTotals[compareApp1] || {}).sort(),
    datasets: [
      {
        label: compareApp1,
        data: Object.keys(compareTotals[compareApp1] || {}).sort().map(date => compareTotals[compareApp1][date]),
        borderColor: 'rgba(75, 192, 192, 1)',
        backgroundColor: 'rgba(75, 192, 192, 0.2)',
      },
      {
        label: compareApp2,
        data: Object.keys(compareTotals[compareApp2] || {}).sort().map(date => compareTotals[compareApp2][date]),
        borderColor: 'rgba(255, 99, 132, 1)',
        backgroundColor: 'rgba(255, 99, 132, 0.2)',
      }
    ]
  };

  const compareOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'top' as const,
      },
      title: {
        display: false,
      },
    },
  };

  return (
    <LocalizationProvider dateAdapter={AdapterDateFns}>
      <Box sx={{ flexGrow: 1, pb: 4 }}>
        <Typography
          variant="h4"
          gutterBottom
          sx={{
            fontWeight: 700,
            background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            mb: 3
          }}
        >
          Usage Dashboard
        </Typography>

        {/* Filters */}
        <Paper
          sx={{
            p: 3,
            mb: 3,
            background: 'rgba(255, 255, 255, 0.95)',
            backdropFilter: 'blur(10px)',
            borderRadius: 2,
            boxShadow: '0 8px 32px 0 rgba(31, 38, 135, 0.1)',
            border: '1px solid rgba(255, 255, 255, 0.2)'
          }}
        >
          <Typography variant="h6" sx={{ mb: 2, fontWeight: 600, color: '#667eea' }}>
            Filters & Date Range
          </Typography>
          <Grid container spacing={2} alignItems="center">
            <Grid item xs={12} sm={3}>
              <DatePicker
                label="Start Date"
                value={startDate}
                onChange={setStartDate}
                renderInput={(params) => <TextField {...params} />}
              />
            </Grid>
            <Grid item xs={12} sm={3}>
              <DatePicker
                label="End Date"
                value={endDate}
                onChange={setEndDate}
                renderInput={(params) => <TextField {...params} />}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <FormGroup row>
                {['Productivity', 'Communication', 'Development'].map(type => (
                  <FormControlLabel
                    key={type}
                    control={
                      <Checkbox
                        checked={selectedTypes.includes(type)}
                        onChange={() => handleTypeChange(type)}
                      />
                    }
                    label={type}
                  />
                ))}
              </FormGroup>
            </Grid>
          </Grid>
        </Paper>

        {/* Graphs */}
        <Grid container spacing={3}>
          <Grid item xs={12} md={6}>
            <Paper sx={{
              p: 3,
              height: 400,
              background: 'rgba(255, 255, 255, 0.95)',
              backdropFilter: 'blur(10px)',
              borderRadius: 2,
              boxShadow: '0 8px 32px 0 rgba(31, 38, 135, 0.1)',
              border: '1px solid rgba(255, 255, 255, 0.2)',
              transition: 'transform 0.3s ease, box-shadow 0.3s ease',
              '&:hover': {
                transform: 'translateY(-5px)',
                boxShadow: '0 12px 40px 0 rgba(31, 38, 135, 0.2)',
              }
            }}>
              <Typography
                variant="h6"
                gutterBottom
                sx={{ fontWeight: 600, color: '#667eea' }}
              >
                📊 Total Application Usage (Bar Chart)
              </Typography>
              <Box sx={{ height: 300 }}>
                <Bar data={barData} options={barOptions} />
              </Box>
            </Paper>
          </Grid>
          <Grid item xs={12} md={6}>
            <Paper sx={{
              p: 3,
              height: 400,
              background: 'rgba(255, 255, 255, 0.95)',
              backdropFilter: 'blur(10px)',
              borderRadius: 2,
              boxShadow: '0 8px 32px 0 rgba(31, 38, 135, 0.1)',
              border: '1px solid rgba(255, 255, 255, 0.2)',
              transition: 'transform 0.3s ease, box-shadow 0.3s ease',
              '&:hover': {
                transform: 'translateY(-5px)',
                boxShadow: '0 12px 40px 0 rgba(31, 38, 135, 0.2)',
              }
            }}>
              <Typography
                variant="h6"
                gutterBottom
                sx={{ fontWeight: 600, color: '#764ba2' }}
              >
                📈 Usage Trend (Line Chart)
              </Typography>
              <Box sx={{ height: 300 }}>
                <Line data={lineData} options={lineOptions} />
              </Box>
              <Button
                variant="contained"
                onClick={exportToExcel}
                sx={{
                  mt: 2,
                  background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                  fontWeight: 600,
                  textTransform: 'none',
                  borderRadius: 1.5,
                  '&:hover': {
                    background: 'linear-gradient(135deg, #5568d3 0%, #6a3f91 100%)',
                  }
                }}
              >
                ⬇️ Download Excel
              </Button>
            </Paper>
          </Grid>
          <Grid item xs={12}>
            <Paper sx={{
              p: 3,
              height: 500,
              background: 'rgba(255, 255, 255, 0.95)',
              backdropFilter: 'blur(10px)',
              borderRadius: 2,
              boxShadow: '0 8px 32px 0 rgba(31, 38, 135, 0.1)',
              border: '1px solid rgba(255, 255, 255, 0.2)',
              transition: 'transform 0.3s ease, box-shadow 0.3s ease',
              '&:hover': {
                transform: 'translateY(-5px)',
                boxShadow: '0 12px 40px 0 rgba(31, 38, 135, 0.2)',
              }
            }}>
              <Typography
                variant="h6"
                gutterBottom
                sx={{ fontWeight: 600, color: '#667eea', mb: 2 }}
              >
                🔄 Application Comparison
              </Typography>
              <Grid container spacing={2} sx={{ mb: 2 }}>
                <Grid item xs={12} sm={4}>
                  <FormControl fullWidth>
                    <InputLabel>Application 1</InputLabel>
                    <Select
                      value={compareApp1}
                      onChange={(e) => setCompareApp1(e.target.value)}
                      sx={{
                        borderRadius: 1.5,
                        '& .MuiOutlinedInput-root': {
                          transition: 'box-shadow 0.3s ease',
                          '&:hover fieldset': {
                            borderColor: '#667eea',
                          },
                        }
                      }}
                    >
                      {Array.from({ length: 35 }, (_, i) => `App ${i + 1}`).map(app => (
                        <MenuItem key={app} value={app}>{app}</MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                </Grid>
                <Grid item xs={12} sm={4}>
                  <FormControl fullWidth>
                    <InputLabel>Application 2</InputLabel>
                    <Select
                      value={compareApp2}
                      onChange={(e) => setCompareApp2(e.target.value)}
                      sx={{
                        borderRadius: 1.5,
                        '& .MuiOutlinedInput-root': {
                          transition: 'box-shadow 0.3s ease',
                          '&:hover fieldset': {
                            borderColor: '#764ba2',
                          },
                        }
                      }}
                    >
                      {Array.from({ length: 35 }, (_, i) => `App ${i + 1}`).map(app => (
                        <MenuItem key={app} value={app}>{app}</MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                </Grid>
              </Grid>
              <Box sx={{ height: 350 }}>
                <Line data={compareChartData} options={compareOptions} />
              </Box>
            </Paper>
          </Grid>
        </Grid>
      </Box>
    </LocalizationProvider>
  );
};

export default UsageDashboard;