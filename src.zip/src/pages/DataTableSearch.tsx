import React, { useState, useEffect } from 'react';
import {
  Paper, Typography, TextField, Table, TableBody, TableCell, TableContainer,
  TableHead, TableRow, TablePagination, FormControl, InputLabel, Select,
  MenuItem, Box, InputAdornment, IconButton
} from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import ClearIcon from '@mui/icons-material/Clear';

// Mock data for the table
const generateTableData = (rows: number) => {
  const categories = ['Category A', 'Category B', 'Category C'];
  const subcategories = {
    'Category A': ['Sub A1', 'Sub A2', 'Sub A3'],
    'Category B': ['Sub B1', 'Sub B2'],
    'Category C': ['Sub C1', 'Sub C2', 'Sub C3', 'Sub C4']
  };
  const details = {
    'Sub A1': ['Detail A1-1', 'Detail A1-2'],
    'Sub A2': ['Detail A2-1'],
    'Sub A3': ['Detail A3-1', 'Detail A3-2', 'Detail A3-3'],
    'Sub B1': ['Detail B1-1', 'Detail B1-2'],
    'Sub B2': ['Detail B2-1'],
    'Sub C1': ['Detail C1-1'],
    'Sub C2': ['Detail C2-1', 'Detail C2-2'],
    'Sub C3': ['Detail C3-1', 'Detail C3-2', 'Detail C3-3'],
    'Sub C4': ['Detail C4-1']
  };

  return Array.from({ length: rows }, (_, i) => ({
    id: i + 1,
    column1: `Item ${i + 1} - ${['Apple', 'Banana', 'Cherry', 'Date', 'Elderberry'][i % 5]}`,
    column2: categories[i % categories.length],
    column3: '',
    column4: '',
    column5: Math.floor(Math.random() * 1000),
    column6: `Info ${i + 1}`
  }));
};

const mockTableData = generateTableData(100);

const DataTableSearch: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredData, setFilteredData] = useState(mockTableData);
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);

  // State for cascading dropdowns
  const [selectedCategories, setSelectedCategories] = useState<Record<number, string>>({});
  const [selectedSubcategories, setSelectedSubcategories] = useState<Record<number, string>>({});
  const [selectedDetails, setSelectedDetails] = useState<Record<number, string>>({});

  const categories = ['Category A', 'Category B', 'Category C'];
  const subcategories: Record<string, string[]> = {
    'Category A': ['Sub A1', 'Sub A2', 'Sub A3'],
    'Category B': ['Sub B1', 'Sub B2'],
    'Category C': ['Sub C1', 'Sub C2', 'Sub C3', 'Sub C4']
  };
  const details: Record<string, string[]> = {
    'Sub A1': ['Detail A1-1', 'Detail A1-2'],
    'Sub A2': ['Detail A2-1'],
    'Sub A3': ['Detail A3-1', 'Detail A3-2', 'Detail A3-3'],
    'Sub B1': ['Detail B1-1', 'Detail B1-2'],
    'Sub B2': ['Detail B2-1'],
    'Sub C1': ['Detail C1-1'],
    'Sub C2': ['Detail C2-1', 'Detail C2-2'],
    'Sub C3': ['Detail C3-1', 'Detail C3-2', 'Detail C3-3'],
    'Sub C4': ['Detail C4-1']
  };

  useEffect(() => {
    const filtered = mockTableData.filter(item =>
      item.column1.toLowerCase().includes(searchTerm.toLowerCase())
    );
    setFilteredData(filtered);
    setPage(0);
  }, [searchTerm]);

  const handleChangePage = (event: unknown, newPage: number) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event: React.ChangeEvent<HTMLInputElement>) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const handleCategoryChange = (id: number, category: string) => {
    setSelectedCategories(prev => ({ ...prev, [id]: category }));
    // Reset dependent fields
    setSelectedSubcategories(prev => ({ ...prev, [id]: '' }));
    setSelectedDetails(prev => ({ ...prev, [id]: '' }));
  };

  const handleSubcategoryChange = (id: number, subcategory: string) => {
    setSelectedSubcategories(prev => ({ ...prev, [id]: subcategory }));
    // Reset dependent field
    setSelectedDetails(prev => ({ ...prev, [id]: '' }));
  };

  const handleDetailChange = (id: number, detail: string) => {
    setSelectedDetails(prev => ({ ...prev, [id]: detail }));
  };

  const clearSearch = () => {
    setSearchTerm('');
  };

  const paginatedData = filteredData.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage);

  return (
    <Box sx={{ flexGrow: 1, pb: 4 }}>
      <Typography
        variant="h4"
        gutterBottom
        sx={{
          fontWeight: 700,
          background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
          WebkitBackgroundClip: 'text',
          WebkitTextFillColor: 'transparent',
          mb: 3
        }}
      >
        Data Table & Search
      </Typography>

      {/* Search Bar */}
      <Paper
        sx={{
          p: 2.5,
          mb: 3,
          background: 'rgba(255, 255, 255, 0.95)',
          backdropFilter: 'blur(10px)',
          borderRadius: 2,
          boxShadow: '0 8px 32px 0 rgba(31, 38, 135, 0.1)',
          border: '1px solid rgba(255, 255, 255, 0.2)'
        }}
      >
        <TextField
          fullWidth
          variant="outlined"
          placeholder="🔍 Search by first column..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          sx={{
            '& .MuiOutlinedInput-root': {
              borderRadius: 1.5,
              transition: 'box-shadow 0.3s ease, border-color 0.3s ease',
              '&:hover fieldset': {
                borderColor: '#667eea',
              },
              '&.Mui-focused fieldset': {
                borderColor: '#764ba2',
                boxShadow: '0 0 0 3px rgba(118, 75, 162, 0.1)',
              }
            }
          }}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <SearchIcon sx={{ color: '#667eea' }} />
              </InputAdornment>
            ),
            endAdornment: searchTerm && (
              <InputAdornment position="end">
                <IconButton
                  onClick={clearSearch}
                  sx={{
                    '&:hover': {
                      backgroundColor: 'rgba(102, 126, 234, 0.1)',
                    }
                  }}
                >
                  <ClearIcon />
                </IconButton>
              </InputAdornment>
            ),
          }}
        />
      </Paper>

      {/* Table */}
      <Paper
        sx={{
          width: '100%',
          overflow: 'hidden',
          background: 'rgba(255, 255, 255, 0.95)',
          backdropFilter: 'blur(10px)',
          borderRadius: 2,
          boxShadow: '0 8px 32px 0 rgba(31, 38, 135, 0.1)',
          border: '1px solid rgba(255, 255, 255, 0.2)'
        }}
      >
        <TableContainer sx={{ maxHeight: 600 }}>
          <Table stickyHeader>
            <TableHead>
              <TableRow sx={{
                backgroundColor: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                '& th': {
                  backgroundColor: '#667eea',
                  color: 'white',
                  fontWeight: 700,
                }
              }}>
                <TableCell sx={{ color: 'white', fontWeight: 700 }}>Column 1 (Searchable)</TableCell>
                <TableCell sx={{ color: 'white', fontWeight: 700 }}>Column 2 (Category)</TableCell>
                <TableCell sx={{ color: 'white', fontWeight: 700 }}>Column 1 (Searchable)</TableCell>
                <TableCell sx={{ color: 'white', fontWeight: 700 }}>Column 2 (Category)</TableCell>
                <TableCell sx={{ color: 'white', fontWeight: 700 }}>Column 3 (Subcategory)</TableCell>
                <TableCell sx={{ color: 'white', fontWeight: 700 }}>Column 4 (Detail)</TableCell>
                <TableCell sx={{ color: 'white', fontWeight: 700 }}>Column 5 (Value)</TableCell>
                <TableCell sx={{ color: 'white', fontWeight: 700 }}>Column 6 (Info)</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {paginatedData.map((row, index) => (
                <TableRow
                  key={row.id}
                  sx={{
                    backgroundColor: index % 2 === 0 ? 'rgba(102, 126, 234, 0.03)' : 'white',
                    '&:hover': {
                      backgroundColor: 'rgba(102, 126, 234, 0.1)',
                      transition: 'background-color 0.2s ease',
                    }
                  }}
                >
                  <TableCell sx={{ fontWeight: 500 }}>{row.column1}</TableCell>
                  <TableCell>
                    <FormControl fullWidth size="small">
                      <InputLabel>Category</InputLabel>
                      <Select
                        value={selectedCategories[row.id] || ''}
                        onChange={(e) => handleCategoryChange(row.id, e.target.value)}
                        sx={{
                          borderRadius: 1,
                          '& .MuiOutlinedInput-root': {
                            '&:hover fieldset': {
                              borderColor: '#667eea',
                            },
                            '&.Mui-focused fieldset': {
                              borderColor: '#764ba2',
                            }
                          }
                        }}
                      >
                        {categories.map(cat => (
                          <MenuItem key={cat} value={cat}>{cat}</MenuItem>
                        ))}
                      </Select>
                    </FormControl>
                  </TableCell>
                  <TableCell>
                    <FormControl fullWidth size="small" disabled={!selectedCategories[row.id]}>
                      <InputLabel>Subcategory</InputLabel>
                      <Select
                        value={selectedSubcategories[row.id] || ''}
                        onChange={(e) => handleSubcategoryChange(row.id, e.target.value)}
                        sx={{
                          borderRadius: 1,
                          '& .MuiOutlinedInput-root': {
                            '&:hover fieldset': {
                              borderColor: '#667eea',
                            },
                            '&.Mui-focused fieldset': {
                              borderColor: '#764ba2',
                            }
                          }
                        }}
                      >
                        {(selectedCategories[row.id] ? subcategories[selectedCategories[row.id]] : []).map(sub => (
                          <MenuItem key={sub} value={sub}>{sub}</MenuItem>
                        ))}
                      </Select>
                    </FormControl>
                  </TableCell>
                  <TableCell>
                    <FormControl fullWidth size="small" disabled={!selectedSubcategories[row.id]}>
                      <InputLabel>Detail</InputLabel>
                      <Select
                        value={selectedDetails[row.id] || ''}
                        onChange={(e) => handleDetailChange(row.id, e.target.value)}
                        sx={{
                          borderRadius: 1,
                          '& .MuiOutlinedInput-root': {
                            '&:hover fieldset': {
                              borderColor: '#667eea',
                            },
                            '&.Mui-focused fieldset': {
                              borderColor: '#764ba2',
                            }
                          }
                        }}
                      >
                        {(selectedSubcategories[row.id] ? details[selectedSubcategories[row.id]] : []).map(detail => (
                          <MenuItem key={detail} value={detail}>{detail}</MenuItem>
                        ))}
                      </Select>
                    </FormControl>
                  </TableCell>
                  <TableCell sx={{ fontWeight: 500 }}>{row.column5}</TableCell>
                  <TableCell sx={{ fontWeight: 500 }}>{row.column5}</TableCell>
                  <TableCell>{row.column6}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
        <TablePagination
          rowsPerPageOptions={[5, 10, 25]}
          component="div"
          count={filteredData.length}
          rowsPerPage={rowsPerPage}
          page={page}
          onPageChange={handleChangePage}
          onRowsPerPageChange={handleChangeRowsPerPage}
          sx={{
            backgroundColor: 'rgba(102, 126, 234, 0.05)',
            borderTop: '1px solid rgba(102, 126, 234, 0.1)',
            '& .MuiTablePagination-selectLabel, & .MuiTablePagination-displayedRows': {
              fontWeight: 500,
              color: '#667eea',
            },
            '& .MuiIconButton-root': {
              '&:hover': {
                backgroundColor: 'rgba(102, 126, 234, 0.1)',
              }
            }
          }}
        />
      </Paper>
    </Box>
  );
};

export default DataTableSearch;